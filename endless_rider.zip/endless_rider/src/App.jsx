
import React, { useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Environment } from '@react-three/drei'

function Player() {
  const ref = useRef()
  useFrame((state,delta)=>{
    ref.current.position.z -= 5*delta
  })
  return (
    <mesh ref={ref} position={[0,0,2]}>
      <boxGeometry args={[1,1,2]} />
      <meshStandardMaterial color={'hotpink'} />
    </mesh>
  )
}

function Obstacle({x,z}) {
  return (
    <mesh position={[x,0,z]}>
      <boxGeometry args={[1,2,1]} />
      <meshStandardMaterial color={'red'} />
    </mesh>
  )
}

function Obstacles() {
  const items=[]
  for(let i=0;i<20;i++){
    items.push(<Obstacle key={i} x={(Math.random()*6)-3} z={-i*10} />)
  }
  return items
}

export default function App(){
  return (
    <Canvas camera={{position:[0,5,10],fov:60}}>
      <ambientLight intensity={0.6}/>
      <directionalLight position={[5,5,5]} intensity={1}/>
      <Player/>
      <Obstacles/>
      <Environment preset="sunset"/>
    </Canvas>
  )
}
